﻿
namespace Gestor_de_contactos
{
    partial class MenuPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenuPrincipal));
            this.panelSideMenuLateral = new System.Windows.Forms.Panel();
            this.ptbcerrarsesion = new System.Windows.Forms.PictureBox();
            this.ptbcerrar = new System.Windows.Forms.PictureBox();
            this.pibhome = new System.Windows.Forms.PictureBox();
            this.btnmenuprincipal = new System.Windows.Forms.Button();
            this.ptbayuda = new System.Windows.Forms.PictureBox();
            this.ptbpapelera = new System.Windows.Forms.PictureBox();
            this.ptbfriends = new System.Windows.Forms.PictureBox();
            this.ptbnewcontacto = new System.Windows.Forms.PictureBox();
            this.btnAyuda = new System.Windows.Forms.Button();
            this.btnPapelera = new System.Windows.Forms.Button();
            this.btnCtsFrecuentes = new System.Windows.Forms.Button();
            this.btnAgregarContactos = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panelContenedor = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnbuscarayuda = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panelSideMenuLateral.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbcerrarsesion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbcerrar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pibhome)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbayuda)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbpapelera)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbfriends)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbnewcontacto)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // panelSideMenuLateral
            // 
            this.panelSideMenuLateral.AutoScroll = true;
            this.panelSideMenuLateral.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            this.panelSideMenuLateral.Controls.Add(this.ptbcerrarsesion);
            this.panelSideMenuLateral.Controls.Add(this.ptbcerrar);
            this.panelSideMenuLateral.Controls.Add(this.pibhome);
            this.panelSideMenuLateral.Controls.Add(this.btnmenuprincipal);
            this.panelSideMenuLateral.Controls.Add(this.ptbayuda);
            this.panelSideMenuLateral.Controls.Add(this.ptbpapelera);
            this.panelSideMenuLateral.Controls.Add(this.ptbfriends);
            this.panelSideMenuLateral.Controls.Add(this.ptbnewcontacto);
            this.panelSideMenuLateral.Controls.Add(this.btnAyuda);
            this.panelSideMenuLateral.Controls.Add(this.btnPapelera);
            this.panelSideMenuLateral.Controls.Add(this.btnCtsFrecuentes);
            this.panelSideMenuLateral.Controls.Add(this.btnAgregarContactos);
            this.panelSideMenuLateral.Controls.Add(this.panel1);
            this.panelSideMenuLateral.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSideMenuLateral.Location = new System.Drawing.Point(0, 0);
            this.panelSideMenuLateral.Name = "panelSideMenuLateral";
            this.panelSideMenuLateral.Size = new System.Drawing.Size(210, 681);
            this.panelSideMenuLateral.TabIndex = 3;
            this.panelSideMenuLateral.Paint += new System.Windows.Forms.PaintEventHandler(this.panelSideMenuLateral_Paint);
            // 
            // ptbcerrarsesion
            // 
            this.ptbcerrarsesion.Image = ((System.Drawing.Image)(resources.GetObject("ptbcerrarsesion.Image")));
            this.ptbcerrarsesion.Location = new System.Drawing.Point(161, 631);
            this.ptbcerrarsesion.Name = "ptbcerrarsesion";
            this.ptbcerrarsesion.Size = new System.Drawing.Size(41, 38);
            this.ptbcerrarsesion.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ptbcerrarsesion.TabIndex = 15;
            this.ptbcerrarsesion.TabStop = false;
            this.ptbcerrarsesion.Click += new System.EventHandler(this.ptbcerrarsesion_Click);
            // 
            // ptbcerrar
            // 
            this.ptbcerrar.Image = ((System.Drawing.Image)(resources.GetObject("ptbcerrar.Image")));
            this.ptbcerrar.Location = new System.Drawing.Point(12, 631);
            this.ptbcerrar.Name = "ptbcerrar";
            this.ptbcerrar.Size = new System.Drawing.Size(41, 38);
            this.ptbcerrar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ptbcerrar.TabIndex = 14;
            this.ptbcerrar.TabStop = false;
            this.ptbcerrar.Click += new System.EventHandler(this.ptbcerrar_Click);
            // 
            // pibhome
            // 
            this.pibhome.Image = ((System.Drawing.Image)(resources.GetObject("pibhome.Image")));
            this.pibhome.Location = new System.Drawing.Point(3, 287);
            this.pibhome.Name = "pibhome";
            this.pibhome.Size = new System.Drawing.Size(41, 38);
            this.pibhome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pibhome.TabIndex = 13;
            this.pibhome.TabStop = false;
            // 
            // btnmenuprincipal
            // 
            this.btnmenuprincipal.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnmenuprincipal.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnmenuprincipal.FlatAppearance.BorderSize = 0;
            this.btnmenuprincipal.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.btnmenuprincipal.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnmenuprincipal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnmenuprincipal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmenuprincipal.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnmenuprincipal.Location = new System.Drawing.Point(0, 280);
            this.btnmenuprincipal.Margin = new System.Windows.Forms.Padding(4);
            this.btnmenuprincipal.Name = "btnmenuprincipal";
            this.btnmenuprincipal.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnmenuprincipal.Size = new System.Drawing.Size(210, 45);
            this.btnmenuprincipal.TabIndex = 12;
            this.btnmenuprincipal.Text = "Menu principal";
            this.btnmenuprincipal.UseVisualStyleBackColor = true;
            this.btnmenuprincipal.Click += new System.EventHandler(this.button1_Click);
            // 
            // ptbayuda
            // 
            this.ptbayuda.Image = ((System.Drawing.Image)(resources.GetObject("ptbayuda.Image")));
            this.ptbayuda.Location = new System.Drawing.Point(3, 242);
            this.ptbayuda.Name = "ptbayuda";
            this.ptbayuda.Size = new System.Drawing.Size(41, 38);
            this.ptbayuda.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ptbayuda.TabIndex = 11;
            this.ptbayuda.TabStop = false;
            // 
            // ptbpapelera
            // 
            this.ptbpapelera.Image = ((System.Drawing.Image)(resources.GetObject("ptbpapelera.Image")));
            this.ptbpapelera.Location = new System.Drawing.Point(3, 197);
            this.ptbpapelera.Name = "ptbpapelera";
            this.ptbpapelera.Size = new System.Drawing.Size(41, 38);
            this.ptbpapelera.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ptbpapelera.TabIndex = 10;
            this.ptbpapelera.TabStop = false;
            // 
            // ptbfriends
            // 
            this.ptbfriends.Image = ((System.Drawing.Image)(resources.GetObject("ptbfriends.Image")));
            this.ptbfriends.Location = new System.Drawing.Point(3, 152);
            this.ptbfriends.Name = "ptbfriends";
            this.ptbfriends.Size = new System.Drawing.Size(41, 38);
            this.ptbfriends.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ptbfriends.TabIndex = 9;
            this.ptbfriends.TabStop = false;
            // 
            // ptbnewcontacto
            // 
            this.ptbnewcontacto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ptbnewcontacto.Image = ((System.Drawing.Image)(resources.GetObject("ptbnewcontacto.Image")));
            this.ptbnewcontacto.Location = new System.Drawing.Point(3, 105);
            this.ptbnewcontacto.Name = "ptbnewcontacto";
            this.ptbnewcontacto.Size = new System.Drawing.Size(44, 40);
            this.ptbnewcontacto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ptbnewcontacto.TabIndex = 8;
            this.ptbnewcontacto.TabStop = false;
            // 
            // btnAyuda
            // 
            this.btnAyuda.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAyuda.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnAyuda.FlatAppearance.BorderSize = 0;
            this.btnAyuda.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.btnAyuda.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnAyuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAyuda.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAyuda.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnAyuda.Location = new System.Drawing.Point(0, 235);
            this.btnAyuda.Margin = new System.Windows.Forms.Padding(4);
            this.btnAyuda.Name = "btnAyuda";
            this.btnAyuda.Size = new System.Drawing.Size(210, 45);
            this.btnAyuda.TabIndex = 7;
            this.btnAyuda.Text = "Ayuda";
            this.btnAyuda.UseVisualStyleBackColor = true;
            this.btnAyuda.Click += new System.EventHandler(this.btnAyuda_Click);
            // 
            // btnPapelera
            // 
            this.btnPapelera.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnPapelera.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnPapelera.FlatAppearance.BorderSize = 0;
            this.btnPapelera.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.btnPapelera.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnPapelera.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPapelera.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPapelera.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnPapelera.Location = new System.Drawing.Point(0, 190);
            this.btnPapelera.Margin = new System.Windows.Forms.Padding(4);
            this.btnPapelera.Name = "btnPapelera";
            this.btnPapelera.Size = new System.Drawing.Size(210, 45);
            this.btnPapelera.TabIndex = 6;
            this.btnPapelera.Text = "Papelera";
            this.btnPapelera.UseVisualStyleBackColor = true;
            this.btnPapelera.Click += new System.EventHandler(this.btnPapelera_Click);
            // 
            // btnCtsFrecuentes
            // 
            this.btnCtsFrecuentes.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCtsFrecuentes.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnCtsFrecuentes.FlatAppearance.BorderSize = 0;
            this.btnCtsFrecuentes.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.btnCtsFrecuentes.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCtsFrecuentes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCtsFrecuentes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCtsFrecuentes.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnCtsFrecuentes.Location = new System.Drawing.Point(0, 145);
            this.btnCtsFrecuentes.Margin = new System.Windows.Forms.Padding(4);
            this.btnCtsFrecuentes.Name = "btnCtsFrecuentes";
            this.btnCtsFrecuentes.Padding = new System.Windows.Forms.Padding(25, 0, 0, 0);
            this.btnCtsFrecuentes.Size = new System.Drawing.Size(210, 45);
            this.btnCtsFrecuentes.TabIndex = 5;
            this.btnCtsFrecuentes.Text = "  Contactos frecuentes";
            this.btnCtsFrecuentes.UseVisualStyleBackColor = true;
            this.btnCtsFrecuentes.Click += new System.EventHandler(this.btnCtsFrecuentes_Click);
            // 
            // btnAgregarContactos
            // 
            this.btnAgregarContactos.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAgregarContactos.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnAgregarContactos.FlatAppearance.BorderSize = 0;
            this.btnAgregarContactos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.btnAgregarContactos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnAgregarContactos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgregarContactos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgregarContactos.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnAgregarContactos.Location = new System.Drawing.Point(0, 100);
            this.btnAgregarContactos.Margin = new System.Windows.Forms.Padding(4);
            this.btnAgregarContactos.Name = "btnAgregarContactos";
            this.btnAgregarContactos.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnAgregarContactos.Size = new System.Drawing.Size(210, 45);
            this.btnAgregarContactos.TabIndex = 4;
            this.btnAgregarContactos.Text = "   Agregar contactos";
            this.btnAgregarContactos.UseVisualStyleBackColor = true;
            this.btnAgregarContactos.Click += new System.EventHandler(this.btnAgregarContactos_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(210, 100);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(51, -1);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(107, 101);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // panelContenedor
            // 
            this.panelContenedor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.panelContenedor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelContenedor.Location = new System.Drawing.Point(210, 0);
            this.panelContenedor.Name = "panelContenedor";
            this.panelContenedor.Size = new System.Drawing.Size(854, 681);
            this.panelContenedor.TabIndex = 4;
            this.panelContenedor.Paint += new System.Windows.Forms.PaintEventHandler(this.panelContenedor_Paint);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            this.panel2.Controls.Add(this.pictureBox3);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.btnbuscarayuda);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(210, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(854, 33);
            this.panel2.TabIndex = 0;
            // 
            // btnbuscarayuda
            // 
            this.btnbuscarayuda.Location = new System.Drawing.Point(7, 4);
            this.btnbuscarayuda.Margin = new System.Windows.Forms.Padding(4);
            this.btnbuscarayuda.Name = "btnbuscarayuda";
            this.btnbuscarayuda.Size = new System.Drawing.Size(625, 24);
            this.btnbuscarayuda.TabIndex = 4;
            this.btnbuscarayuda.Text = "buscar";
            this.btnbuscarayuda.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(755, -1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(35, 34);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(796, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(35, 34);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 17;
            this.pictureBox3.TabStop = false;
            // 
            // MenuPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1064, 681);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panelContenedor);
            this.Controls.Add(this.panelSideMenuLateral);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MenuPrincipal";
            this.Text = "Panel";
            this.Load += new System.EventHandler(this.MenuPrincipal_Load);
            this.panelSideMenuLateral.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ptbcerrarsesion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbcerrar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pibhome)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbayuda)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbpapelera)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbfriends)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbnewcontacto)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panelSideMenuLateral;
        private System.Windows.Forms.Button btnAgregarContactos;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btnAyuda;
        private System.Windows.Forms.Button btnPapelera;
        private System.Windows.Forms.Button btnCtsFrecuentes;
        private System.Windows.Forms.PictureBox ptbayuda;
        private System.Windows.Forms.PictureBox ptbpapelera;
        private System.Windows.Forms.PictureBox ptbfriends;
        private System.Windows.Forms.PictureBox ptbnewcontacto;
        private System.Windows.Forms.Panel panelContenedor;
        private System.Windows.Forms.Button btnmenuprincipal;
        private System.Windows.Forms.PictureBox ptbcerrarsesion;
        private System.Windows.Forms.PictureBox ptbcerrar;
        private System.Windows.Forms.PictureBox pibhome;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnbuscarayuda;
    }
}