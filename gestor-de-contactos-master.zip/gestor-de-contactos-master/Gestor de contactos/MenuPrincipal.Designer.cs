﻿
namespace Gestor_de_contactos
{
    partial class MenuPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenuPrincipal));
            this.pictureajustes = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.Button();
            this.panelSideMenuLateral = new System.Windows.Forms.Panel();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.btnAyuda = new System.Windows.Forms.Button();
            this.btnPapelera = new System.Windows.Forms.Button();
            this.btnCtsFrecuentes = new System.Windows.Forms.Button();
            this.btnAgregarContactos = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panelContenedor = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureajustes)).BeginInit();
            this.panelSideMenuLateral.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panelContenedor.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureajustes
            // 
            this.pictureajustes.Image = ((System.Drawing.Image)(resources.GetObject("pictureajustes.Image")));
            this.pictureajustes.Location = new System.Drawing.Point(859, 13);
            this.pictureajustes.Margin = new System.Windows.Forms.Padding(4);
            this.pictureajustes.Name = "pictureajustes";
            this.pictureajustes.Size = new System.Drawing.Size(61, 34);
            this.pictureajustes.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureajustes.TabIndex = 0;
            this.pictureajustes.TabStop = false;
            this.pictureajustes.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(9, 4);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(464, 38);
            this.button2.TabIndex = 2;
            this.button2.Text = "buscar";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // panelSideMenuLateral
            // 
            this.panelSideMenuLateral.AutoScroll = true;
            this.panelSideMenuLateral.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            this.panelSideMenuLateral.Controls.Add(this.pictureBox6);
            this.panelSideMenuLateral.Controls.Add(this.pictureBox5);
            this.panelSideMenuLateral.Controls.Add(this.pictureBox4);
            this.panelSideMenuLateral.Controls.Add(this.pictureBox3);
            this.panelSideMenuLateral.Controls.Add(this.btnAyuda);
            this.panelSideMenuLateral.Controls.Add(this.btnPapelera);
            this.panelSideMenuLateral.Controls.Add(this.btnCtsFrecuentes);
            this.panelSideMenuLateral.Controls.Add(this.btnAgregarContactos);
            this.panelSideMenuLateral.Controls.Add(this.panel1);
            this.panelSideMenuLateral.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSideMenuLateral.Location = new System.Drawing.Point(0, 0);
            this.panelSideMenuLateral.Name = "panelSideMenuLateral";
            this.panelSideMenuLateral.Size = new System.Drawing.Size(210, 561);
            this.panelSideMenuLateral.TabIndex = 3;
            this.panelSideMenuLateral.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(3, 242);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(41, 38);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 11;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(3, 197);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(41, 38);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 10;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(3, 152);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(41, 38);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 9;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(3, 106);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(41, 39);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 8;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // btnAyuda
            // 
            this.btnAyuda.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAyuda.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnAyuda.FlatAppearance.BorderSize = 0;
            this.btnAyuda.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.btnAyuda.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnAyuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAyuda.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAyuda.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnAyuda.Location = new System.Drawing.Point(0, 235);
            this.btnAyuda.Margin = new System.Windows.Forms.Padding(4);
            this.btnAyuda.Name = "btnAyuda";
            this.btnAyuda.Size = new System.Drawing.Size(210, 45);
            this.btnAyuda.TabIndex = 7;
            this.btnAyuda.Text = "Ayuda";
            this.btnAyuda.UseVisualStyleBackColor = true;
            this.btnAyuda.Click += new System.EventHandler(this.button4_Click);
            // 
            // btnPapelera
            // 
            this.btnPapelera.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnPapelera.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnPapelera.FlatAppearance.BorderSize = 0;
            this.btnPapelera.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.btnPapelera.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnPapelera.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPapelera.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPapelera.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnPapelera.Location = new System.Drawing.Point(0, 190);
            this.btnPapelera.Margin = new System.Windows.Forms.Padding(4);
            this.btnPapelera.Name = "btnPapelera";
            this.btnPapelera.Size = new System.Drawing.Size(210, 45);
            this.btnPapelera.TabIndex = 6;
            this.btnPapelera.Text = "Papelera";
            this.btnPapelera.UseVisualStyleBackColor = true;
            // 
            // btnCtsFrecuentes
            // 
            this.btnCtsFrecuentes.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCtsFrecuentes.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnCtsFrecuentes.FlatAppearance.BorderSize = 0;
            this.btnCtsFrecuentes.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.btnCtsFrecuentes.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCtsFrecuentes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCtsFrecuentes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCtsFrecuentes.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnCtsFrecuentes.Location = new System.Drawing.Point(0, 145);
            this.btnCtsFrecuentes.Margin = new System.Windows.Forms.Padding(4);
            this.btnCtsFrecuentes.Name = "btnCtsFrecuentes";
            this.btnCtsFrecuentes.Padding = new System.Windows.Forms.Padding(25, 0, 0, 0);
            this.btnCtsFrecuentes.Size = new System.Drawing.Size(210, 45);
            this.btnCtsFrecuentes.TabIndex = 5;
            this.btnCtsFrecuentes.Text = "Contactos frecuentes";
            this.btnCtsFrecuentes.UseVisualStyleBackColor = true;
            // 
            // btnAgregarContactos
            // 
            this.btnAgregarContactos.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAgregarContactos.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnAgregarContactos.FlatAppearance.BorderSize = 0;
            this.btnAgregarContactos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.btnAgregarContactos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnAgregarContactos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgregarContactos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgregarContactos.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnAgregarContactos.Location = new System.Drawing.Point(0, 100);
            this.btnAgregarContactos.Margin = new System.Windows.Forms.Padding(4);
            this.btnAgregarContactos.Name = "btnAgregarContactos";
            this.btnAgregarContactos.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnAgregarContactos.Size = new System.Drawing.Size(210, 45);
            this.btnAgregarContactos.TabIndex = 4;
            this.btnAgregarContactos.Text = "Agregar contactos";
            this.btnAgregarContactos.UseVisualStyleBackColor = true;
            this.btnAgregarContactos.Click += new System.EventHandler(this.btnAgregarContactos_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(210, 100);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(51, -1);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(107, 101);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // panelContenedor
            // 
            this.panelContenedor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.panelContenedor.Controls.Add(this.button2);
            this.panelContenedor.Location = new System.Drawing.Point(208, 0);
            this.panelContenedor.Name = "panelContenedor";
            this.panelContenedor.Size = new System.Drawing.Size(1300, 740);
            this.panelContenedor.TabIndex = 4;
            this.panelContenedor.Paint += new System.Windows.Forms.PaintEventHandler(this.panelContenedor_Paint);
            // 
            // MenuPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(934, 561);
            this.Controls.Add(this.panelContenedor);
            this.Controls.Add(this.panelSideMenuLateral);
            this.Controls.Add(this.pictureajustes);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(950, 600);
            this.Name = "MenuPrincipal";
            this.Text = "Panel";
            this.Load += new System.EventHandler(this.Home_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureajustes)).EndInit();
            this.panelSideMenuLateral.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panelContenedor.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureajustes;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panelSideMenuLateral;
        private System.Windows.Forms.Button btnAgregarContactos;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btnAyuda;
        private System.Windows.Forms.Button btnPapelera;
        private System.Windows.Forms.Button btnCtsFrecuentes;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panelContenedor;
    }
}