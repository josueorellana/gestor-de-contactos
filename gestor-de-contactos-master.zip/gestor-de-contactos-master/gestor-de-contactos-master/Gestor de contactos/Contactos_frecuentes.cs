﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestor_de_contactos
{
    public partial class Contactos_frecuentes : Form
    {
        public Contactos_frecuentes()
        {
            InitializeComponent();
        }
    }
}
